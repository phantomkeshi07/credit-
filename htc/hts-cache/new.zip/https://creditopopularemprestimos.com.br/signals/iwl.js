<!doctype html>
<html lang="pt-BR">
<head>
	<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<title>Página não encontrada &#8211; Crédito Popular Empréstimos</title>
<meta name='robots' content='max-image-preview:large' />
<link rel="alternate" type="application/rss+xml" title="Feed para Crédito Popular Empréstimos &raquo;" href="https://creditopopularemprestimos.com.br/feed/" />
<link rel="alternate" type="application/rss+xml" title="Feed de comentários para Crédito Popular Empréstimos &raquo;" href="https://creditopopularemprestimos.com.br/comments/feed/" />
<script type="text/javascript">
/* <![CDATA[ */
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/creditopopularemprestimos.com.br\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.5.2"}};
/*! This file is auto-generated */
!function(i,n){var o,s,e;function c(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function p(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data),r=(e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0),new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data));return t.every(function(e,t){return e===r[t]})}function u(e,t,n){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\uddfa\ud83c\uddf3","\ud83c\uddfa\u200b\ud83c\uddf3")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!n(e,"\ud83d\udc26\u200d\u2b1b","\ud83d\udc26\u200b\u2b1b")}return!1}function f(e,t,n){var r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):i.createElement("canvas"),a=r.getContext("2d",{willReadFrequently:!0}),o=(a.textBaseline="top",a.font="600 32px Arial",{});return e.forEach(function(e){o[e]=t(a,e,n)}),o}function t(e){var t=i.createElement("script");t.src=e,t.defer=!0,i.head.appendChild(t)}"undefined"!=typeof Promise&&(o="wpEmojiSettingsSupports",s=["flag","emoji"],n.supports={everything:!0,everythingExceptFlag:!0},e=new Promise(function(e){i.addEventListener("DOMContentLoaded",e,{once:!0})}),new Promise(function(t){var n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(s),u.toString(),p.toString()].join(",")+"));",r=new Blob([e],{type:"text/javascript"}),a=new Worker(URL.createObjectURL(r),{name:"wpTestEmojiSupports"});return void(a.onmessage=function(e){c(n=e.data),a.terminate(),t(n)})}catch(e){}c(n=f(s,u,p))}t(n)}).then(function(e){for(var t in e)n.supports[t]=e[t],n.supports.everything=n.supports.everything&&n.supports[t],"flag"!==t&&(n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&n.supports[t]);n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&!n.supports.flag,n.DOMReady=!1,n.readyCallback=function(){n.DOMReady=!0}}).then(function(){return e}).then(function(){var e;n.supports.everything||(n.readyCallback(),(e=n.source||{}).concatemoji?t(e.concatemoji):e.wpemoji&&e.twemoji&&(t(e.twemoji),t(e.wpemoji)))}))}((window,document),window._wpemojiSettings);
/* ]]> */
</script>
<link rel='stylesheet' id='jkit-elements-main-css' href='https://creditopopularemprestimos.com.br/wp-content/plugins/jeg-elementor-kit/assets/css/elements/main.css?ver=2.6.1' type='text/css' media='all' />
<style id='wp-emoji-styles-inline-css' type='text/css'>

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
</style>
<link rel='stylesheet' id='wp-block-library-css' href='https://creditopopularemprestimos.com.br/wp-includes/css/dist/block-library/style.min.css?ver=6.5.2' type='text/css' media='all' />
<link rel='stylesheet' id='jet-engine-frontend-css' href='https://creditopopularemprestimos.com.br/wp-content/plugins/jet-engine/assets/css/frontend.css?ver=3.1.3.1' type='text/css' media='all' />
<style id='classic-theme-styles-inline-css' type='text/css'>
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
</style>
<style id='global-styles-inline-css' type='text/css'>
body{--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flow > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-flow > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-flow > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-constrained > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-constrained > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > :where(:not(.alignleft):not(.alignright):not(.alignfull)){max-width: var(--wp--style--global--content-size);margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignwide{max-width: var(--wp--style--global--wide-size);}body .is-layout-flex{display: flex;}body .is-layout-flex{flex-wrap: wrap;align-items: center;}body .is-layout-flex > *{margin: 0;}body .is-layout-grid{display: grid;}body .is-layout-grid > *{margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
.wp-block-navigation a:where(:not(.wp-element-button)){color: inherit;}
:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}
.wp-block-pullquote{font-size: 1.5em;line-height: 1.6;}
</style>
<link rel='stylesheet' id='elementor-icons-css' href='https://creditopopularemprestimos.com.br/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min.css?ver=5.16.0' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-frontend-css' href='https://creditopopularemprestimos.com.br/wp-content/plugins/elementor/assets/css/frontend-lite.min.css?ver=3.7.8' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-9-css' href='https://creditopopularemprestimos.com.br/wp-content/uploads/elementor/css/post-9.css?ver=1690292673' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-pro-css' href='https://creditopopularemprestimos.com.br/wp-content/plugins/elementor-pro/assets/css/frontend-lite.min.css?ver=3.7.7' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-global-css' href='https://creditopopularemprestimos.com.br/wp-content/uploads/elementor/css/global.css?ver=1690292676' type='text/css' media='all' />
<link rel='stylesheet' id='hello-elementor-css' href='https://creditopopularemprestimos.com.br/wp-content/themes/hello-elementor/style.min.css?ver=2.5.0' type='text/css' media='all' />
<link rel='stylesheet' id='hello-elementor-theme-style-css' href='https://creditopopularemprestimos.com.br/wp-content/themes/hello-elementor/theme.min.css?ver=2.5.0' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-16-css' href='https://creditopopularemprestimos.com.br/wp-content/uploads/elementor/css/post-16.css?ver=1690292689' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-163-css' href='https://creditopopularemprestimos.com.br/wp-content/uploads/elementor/css/post-163.css?ver=1690292689' type='text/css' media='all' />
<link rel='stylesheet' id='eael-general-css' href='https://creditopopularemprestimos.com.br/wp-content/plugins/essential-addons-for-elementor-lite/assets/front-end/css/view/general.min.css?ver=5.4.6' type='text/css' media='all' />
<link rel='stylesheet' id='google-fonts-1-css' href='https://fonts.googleapis.com/css?family=Roboto%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CRoboto+Slab%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&#038;display=auto&#038;ver=6.5.2' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-shared-0-css' href='https://creditopopularemprestimos.com.br/wp-content/plugins/elementor/assets/lib/font-awesome/css/fontawesome.min.css?ver=5.15.3' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-fa-solid-css' href='https://creditopopularemprestimos.com.br/wp-content/plugins/elementor/assets/lib/font-awesome/css/solid.min.css?ver=5.15.3' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-fa-brands-css' href='https://creditopopularemprestimos.com.br/wp-content/plugins/elementor/assets/lib/font-awesome/css/brands.min.css?ver=5.15.3' type='text/css' media='all' />
<script type="text/javascript" src="https://creditopopularemprestimos.com.br/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
<script type="text/javascript" src="https://creditopopularemprestimos.com.br/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
<link rel="https://api.w.org/" href="https://creditopopularemprestimos.com.br/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://creditopopularemprestimos.com.br/xmlrpc.php?rsd" />
<meta name="generator" content="WordPress 6.5.2" />
        <!-- Ultimate Client Dashboard Google Analytics -->
        <script type="text/javascript">
          var _gaq = _gaq || [];
          _gaq.push(['_setAccount', 'UA-224620179-1']);
          _gaq.push(['_trackPageview']);
          (function() {
            var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
            ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
            var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
          })();
        </script>
            <!-- Ultimate Client Dashboard Custom Script -->
        <!-- Meta Pixel Code -->
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '749091546083183');
  fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
  src="https://www.facebook.com/tr?id=749091546083183&ev=PageView&noscript=1"
/></noscript>
<!-- End Meta Pixel Code -->

<!-- Global site tag (gtag.js) - Google Ads: 10876891809 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-10876891809"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-10876891809');
</script>
<!-- Event snippet for Contato-site conversion page
In your html page, add the snippet and call gtag_report_conversion when someone clicks on the chosen link or button. -->
<script>
function gtag_report_conversion(url) {
  var callback = function () {
    if (typeof(url) != 'undefined') {
      window.location = url;
    }
  };
  gtag('event', 'conversion', {
      'send_to': 'AW-10876891809/Xvx_CMv00bQDEKHlwMIo',
      'event_callback': callback
  });
  return false;
}
</script>
<meta name="facebook-domain-verification" content="23sit7czwjtq7joifhu2vz4vuqd6gp" />


<!-- Meta Pixel Code -->
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '1137190017180603');
  fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
  src="https://www.facebook.com/tr?id=1137190017180603&ev=PageView&noscript=1"
/></noscript>
<!-- End Meta Pixel Code -->

<meta name="facebook-domain-verification" content="khsl7j9jk373r5hqop9wsc0a9tq1pp" />


<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NWWWVXQ');</script>
<!-- End Google Tag Manager -->


<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NWWWVXQ"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->


<!-- Meta Pixel Code -->
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '1740383649714017');
  fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
  src="https://www.facebook.com/tr?id=1740383649714017&ev=PageView&noscript=1"
/></noscript>
<!-- End Meta Pixel Code -->    <script>document.createElement( "picture" );if(!window.HTMLPictureElement && document.addEventListener) {window.addEventListener("DOMContentLoaded", function() {var s = document.createElement("script");s.src = "https://creditopopularemprestimos.com.br/wp-content/plugins/webp-express/js/picturefill.min.js";document.body.appendChild(s);});}</script><link rel="icon" href="https://creditopopularemprestimos.com.br/wp-content/uploads/2022/03/cropped-Fav-icon-Credito-Popular-32x32.png" sizes="32x32" />
<link rel="icon" href="https://creditopopularemprestimos.com.br/wp-content/uploads/2022/03/cropped-Fav-icon-Credito-Popular-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://creditopopularemprestimos.com.br/wp-content/uploads/2022/03/cropped-Fav-icon-Credito-Popular-180x180.png" />
<meta name="msapplication-TileImage" content="https://creditopopularemprestimos.com.br/wp-content/uploads/2022/03/cropped-Fav-icon-Credito-Popular-270x270.png" />
</head>
<body class="error404 wp-custom-logo jkit-color-scheme elementor-default elementor-kit-9">

		<div data-elementor-type="header" data-elementor-id="16" class="elementor elementor-16 elementor-location-header">
								<section class="elementor-section elementor-top-section elementor-element elementor-element-47be14d elementor-section-content-middle elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="47be14d" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-751cf85" data-id="751cf85" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-5bbfa9b elementor-widget elementor-widget-theme-site-logo elementor-widget-image" data-id="5bbfa9b" data-element_type="widget" data-widget_type="theme-site-logo.default">
				<div class="elementor-widget-container">
			<style>/*! elementor - v3.7.8 - 02-10-2022 */
.elementor-widget-image{text-align:center}.elementor-widget-image a{display:inline-block}.elementor-widget-image a img[src$=".svg"]{width:48px}.elementor-widget-image img{vertical-align:middle;display:inline-block}</style>													<a href="https://creditopopularemprestimos.com.br">
							<picture><source srcset="https://creditopopularemprestimos.com.br/wp-content/webp-express/webp-images/uploads/2022/02/cropped-Logo-Credito-Popular-Emprestimos-01.png.webp 350w, https://creditopopularemprestimos.com.br/wp-content/webp-express/webp-images/uploads/2022/02/cropped-Logo-Credito-Popular-Emprestimos-01-300x86.png.webp 300w" sizes="(max-width: 350px) 100vw, 350px" type="image/webp"><img width="350" height="100" src="https://creditopopularemprestimos.com.br/wp-content/uploads/2022/02/cropped-Logo-Credito-Popular-Emprestimos-01.png" class="attachment-full size-full webpexpress-processed" alt="" decoding="async" srcset="https://creditopopularemprestimos.com.br/wp-content/uploads/2022/02/cropped-Logo-Credito-Popular-Emprestimos-01.png 350w, https://creditopopularemprestimos.com.br/wp-content/uploads/2022/02/cropped-Logo-Credito-Popular-Emprestimos-01-300x86.png 300w" sizes="(max-width: 350px) 100vw, 350px"></picture>								</a>
															</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-b479750" data-id="b479750" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-9684d8c elementor-nav-menu--dropdown-mobile elementor-nav-menu--stretch elementor-nav-menu__text-align-center elementor-nav-menu--toggle elementor-nav-menu--burger elementor-widget elementor-widget-nav-menu" data-id="9684d8c" data-element_type="widget" data-settings="{&quot;full_width&quot;:&quot;stretch&quot;,&quot;layout&quot;:&quot;horizontal&quot;,&quot;submenu_icon&quot;:{&quot;value&quot;:&quot;&lt;i class=\&quot;fas fa-caret-down\&quot;&gt;&lt;\/i&gt;&quot;,&quot;library&quot;:&quot;fa-solid&quot;},&quot;toggle&quot;:&quot;burger&quot;}" data-widget_type="nav-menu.default">
				<div class="elementor-widget-container">
			<link rel="stylesheet" href="https://creditopopularemprestimos.com.br/wp-content/plugins/elementor-pro/assets/css/widget-nav-menu.min.css">			<nav migration_allowed="1" migrated="0" role="navigation" class="elementor-nav-menu--main elementor-nav-menu__container elementor-nav-menu--layout-horizontal e--pointer-underline e--animation-fade">
				<ul id="menu-1-9684d8c" class="elementor-nav-menu"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-582"><a href="https://creditopopularemprestimos.com.br/agencias/" class="elementor-item">Agências</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-177"><a href="http://creditopopularemprestimos.com.br/#vantagens" class="elementor-item elementor-item-anchor">Vantagens</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1075"><a class="elementor-item">Empréstimos</a>
<ul class="sub-menu elementor-nav-menu--dropdown">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1076"><a href="https://creditopopularemprestimos.com.br/representante-legal/" class="elementor-sub-item">Representante Legal</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-1077"><a href="https://creditopopularemprestimos.com.br/" class="elementor-sub-item">Saque Aniversário FGTS</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1082"><a href="https://api.whatsapp.com/send?phone=5562996970160&#038;text=Ol%C3%A1%2C%20%20gostaria%20de%20fazer%20uma%20simula%C3%A7%C3%A3o%20para%20empr%C3%A9stimo%20Consignado%20Federal%2FEstadual" class="elementor-sub-item">Consignado Federal/Estadual</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-178"><a href="http://creditopopularemprestimos.com.br/#duvidas" class="elementor-item elementor-item-anchor">Dúvidas Frequentes</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-587"><a href="https://creditopopularemprestimos.com.br/sobre-nos/" class="elementor-item">Sobre Nós</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-603"><a href="https://creditopopularemprestimos.com.br/fale-conosco/" class="elementor-item">Fale Conosco</a></li>
</ul>			</nav>
					<div class="elementor-menu-toggle" role="button" tabindex="0" aria-label="Menu Toggle" aria-expanded="false">
			<i aria-hidden="true" role="presentation" class="elementor-menu-toggle__icon--open eicon-menu-bar"></i><i aria-hidden="true" role="presentation" class="elementor-menu-toggle__icon--close eicon-close"></i>			<span class="elementor-screen-only">Menu</span>
		</div>
			<nav class="elementor-nav-menu--dropdown elementor-nav-menu__container" role="navigation" aria-hidden="true">
				<ul id="menu-2-9684d8c" class="elementor-nav-menu"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-582"><a href="https://creditopopularemprestimos.com.br/agencias/" class="elementor-item" tabindex="-1">Agências</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-177"><a href="http://creditopopularemprestimos.com.br/#vantagens" class="elementor-item elementor-item-anchor" tabindex="-1">Vantagens</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1075"><a class="elementor-item" tabindex="-1">Empréstimos</a>
<ul class="sub-menu elementor-nav-menu--dropdown">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1076"><a href="https://creditopopularemprestimos.com.br/representante-legal/" class="elementor-sub-item" tabindex="-1">Representante Legal</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-1077"><a href="https://creditopopularemprestimos.com.br/" class="elementor-sub-item" tabindex="-1">Saque Aniversário FGTS</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1082"><a href="https://api.whatsapp.com/send?phone=5562996970160&#038;text=Ol%C3%A1%2C%20%20gostaria%20de%20fazer%20uma%20simula%C3%A7%C3%A3o%20para%20empr%C3%A9stimo%20Consignado%20Federal%2FEstadual" class="elementor-sub-item" tabindex="-1">Consignado Federal/Estadual</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-178"><a href="http://creditopopularemprestimos.com.br/#duvidas" class="elementor-item elementor-item-anchor" tabindex="-1">Dúvidas Frequentes</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-587"><a href="https://creditopopularemprestimos.com.br/sobre-nos/" class="elementor-item" tabindex="-1">Sobre Nós</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-603"><a href="https://creditopopularemprestimos.com.br/fale-conosco/" class="elementor-item" tabindex="-1">Fale Conosco</a></li>
</ul>			</nav>
				</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-6dd69f5 whatsapp elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="6dd69f5" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-ce36f3e" data-id="ce36f3e" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-3e6edbf elementor-shape-circle elementor-grid-0 e-grid-align-center elementor-widget elementor-widget-social-icons" data-id="3e6edbf" data-element_type="widget" data-widget_type="social-icons.default">
				<div class="elementor-widget-container">
			<style>/*! elementor - v3.7.8 - 02-10-2022 */
.elementor-widget-social-icons.elementor-grid-0 .elementor-widget-container,.elementor-widget-social-icons.elementor-grid-mobile-0 .elementor-widget-container,.elementor-widget-social-icons.elementor-grid-tablet-0 .elementor-widget-container{line-height:1;font-size:0}.elementor-widget-social-icons:not(.elementor-grid-0):not(.elementor-grid-tablet-0):not(.elementor-grid-mobile-0) .elementor-grid{display:inline-grid}.elementor-widget-social-icons .elementor-grid{grid-column-gap:var(--grid-column-gap,5px);grid-row-gap:var(--grid-row-gap,5px);grid-template-columns:var(--grid-template-columns);-webkit-box-pack:var(--justify-content,center);-ms-flex-pack:var(--justify-content,center);justify-content:var(--justify-content,center);justify-items:var(--justify-content,center)}.elementor-icon.elementor-social-icon{font-size:var(--icon-size,25px);line-height:var(--icon-size,25px);width:calc(var(--icon-size, 25px) + (2 * var(--icon-padding, .5em)));height:calc(var(--icon-size, 25px) + (2 * var(--icon-padding, .5em)))}.elementor-social-icon{--e-social-icon-icon-color:#fff;display:-webkit-inline-box;display:-ms-inline-flexbox;display:inline-flex;background-color:#818a91;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center;text-align:center;cursor:pointer}.elementor-social-icon i{color:var(--e-social-icon-icon-color)}.elementor-social-icon svg{fill:var(--e-social-icon-icon-color)}.elementor-social-icon:last-child{margin:0}.elementor-social-icon:hover{opacity:.9;color:#fff}.elementor-social-icon-android{background-color:#a4c639}.elementor-social-icon-apple{background-color:#999}.elementor-social-icon-behance{background-color:#1769ff}.elementor-social-icon-bitbucket{background-color:#205081}.elementor-social-icon-codepen{background-color:#000}.elementor-social-icon-delicious{background-color:#39f}.elementor-social-icon-deviantart{background-color:#05cc47}.elementor-social-icon-digg{background-color:#005be2}.elementor-social-icon-dribbble{background-color:#ea4c89}.elementor-social-icon-elementor{background-color:#d30c5c}.elementor-social-icon-envelope{background-color:#ea4335}.elementor-social-icon-facebook,.elementor-social-icon-facebook-f{background-color:#3b5998}.elementor-social-icon-flickr{background-color:#0063dc}.elementor-social-icon-foursquare{background-color:#2d5be3}.elementor-social-icon-free-code-camp,.elementor-social-icon-freecodecamp{background-color:#006400}.elementor-social-icon-github{background-color:#333}.elementor-social-icon-gitlab{background-color:#e24329}.elementor-social-icon-globe{background-color:#818a91}.elementor-social-icon-google-plus,.elementor-social-icon-google-plus-g{background-color:#dd4b39}.elementor-social-icon-houzz{background-color:#7ac142}.elementor-social-icon-instagram{background-color:#262626}.elementor-social-icon-jsfiddle{background-color:#487aa2}.elementor-social-icon-link{background-color:#818a91}.elementor-social-icon-linkedin,.elementor-social-icon-linkedin-in{background-color:#0077b5}.elementor-social-icon-medium{background-color:#00ab6b}.elementor-social-icon-meetup{background-color:#ec1c40}.elementor-social-icon-mixcloud{background-color:#273a4b}.elementor-social-icon-odnoklassniki{background-color:#f4731c}.elementor-social-icon-pinterest{background-color:#bd081c}.elementor-social-icon-product-hunt{background-color:#da552f}.elementor-social-icon-reddit{background-color:#ff4500}.elementor-social-icon-rss{background-color:#f26522}.elementor-social-icon-shopping-cart{background-color:#4caf50}.elementor-social-icon-skype{background-color:#00aff0}.elementor-social-icon-slideshare{background-color:#0077b5}.elementor-social-icon-snapchat{background-color:#fffc00}.elementor-social-icon-soundcloud{background-color:#f80}.elementor-social-icon-spotify{background-color:#2ebd59}.elementor-social-icon-stack-overflow{background-color:#fe7a15}.elementor-social-icon-steam{background-color:#00adee}.elementor-social-icon-stumbleupon{background-color:#eb4924}.elementor-social-icon-telegram{background-color:#2ca5e0}.elementor-social-icon-thumb-tack{background-color:#1aa1d8}.elementor-social-icon-tripadvisor{background-color:#589442}.elementor-social-icon-tumblr{background-color:#35465c}.elementor-social-icon-twitch{background-color:#6441a5}.elementor-social-icon-twitter{background-color:#1da1f2}.elementor-social-icon-viber{background-color:#665cac}.elementor-social-icon-vimeo{background-color:#1ab7ea}.elementor-social-icon-vk{background-color:#45668e}.elementor-social-icon-weibo{background-color:#dd2430}.elementor-social-icon-weixin{background-color:#31a918}.elementor-social-icon-whatsapp{background-color:#25d366}.elementor-social-icon-wordpress{background-color:#21759b}.elementor-social-icon-xing{background-color:#026466}.elementor-social-icon-yelp{background-color:#af0606}.elementor-social-icon-youtube{background-color:#cd201f}.elementor-social-icon-500px{background-color:#0099e5}.elementor-shape-rounded .elementor-icon.elementor-social-icon{border-radius:10%}.elementor-shape-circle .elementor-icon.elementor-social-icon{border-radius:50%}</style>		<div class="elementor-social-icons-wrapper elementor-grid">
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-whatsapp elementor-repeater-item-ed09ed7" href="https://api.whatsapp.com/send?phone=5562996970160&#038;text=Ol%C3%A1,%20gostaria%20de%20saber%20mais%20sobre%20a%20Antecipa%C3%A7%C3%A3o%20do%20Saque%20Anivers%C3%A1rio%20FGTS." target="_blank">
						<span class="elementor-screen-only">Whatsapp</span>
						<i class="fab fa-whatsapp"></i>					</a>
				</span>
					</div>
				</div>
				</div>
					</div>
		</div>
							</div>
		</section>
						</div>
		<main id="content" class="site-main" role="main">
			<header class="page-header">
			<h1 class="entry-title">Página não encontrada</h1>
		</header>
		<div class="page-content">
		<p>Parece que nada foi encontrado aqui.</p>
	</div>

</main>
		<div data-elementor-type="footer" data-elementor-id="163" class="elementor elementor-163 elementor-location-footer">
								<section class="elementor-section elementor-top-section elementor-element elementor-element-df7c9b3 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="df7c9b3" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-9460c25" data-id="9460c25" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-9501943 elementor-widget elementor-widget-theme-site-logo elementor-widget-image" data-id="9501943" data-element_type="widget" data-widget_type="theme-site-logo.default">
				<div class="elementor-widget-container">
																<a href="https://creditopopularemprestimos.com.br">
							<picture><source srcset="https://creditopopularemprestimos.com.br/wp-content/webp-express/webp-images/uploads/2022/02/cropped-Logo-Credito-Popular-Emprestimos-01.png.webp 350w, https://creditopopularemprestimos.com.br/wp-content/webp-express/webp-images/uploads/2022/02/cropped-Logo-Credito-Popular-Emprestimos-01-300x86.png.webp 300w" sizes="(max-width: 350px) 100vw, 350px" type="image/webp"><img width="350" height="100" src="https://creditopopularemprestimos.com.br/wp-content/uploads/2022/02/cropped-Logo-Credito-Popular-Emprestimos-01.png" class="attachment-full size-full webpexpress-processed" alt="" decoding="async" loading="lazy" srcset="https://creditopopularemprestimos.com.br/wp-content/uploads/2022/02/cropped-Logo-Credito-Popular-Emprestimos-01.png 350w, https://creditopopularemprestimos.com.br/wp-content/uploads/2022/02/cropped-Logo-Credito-Popular-Emprestimos-01-300x86.png 300w" sizes="(max-width: 350px) 100vw, 350px"></picture>								</a>
															</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-f301940" data-id="f301940" data-element_type="column">
			<div class="elementor-widget-wrap">
									</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-19df48f" data-id="19df48f" data-element_type="column">
			<div class="elementor-widget-wrap">
									</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-be6b334 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="be6b334" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-a9d46b0" data-id="a9d46b0" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-053b15d elementor-widget elementor-widget-heading" data-id="053b15d" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<style>/*! elementor - v3.7.8 - 02-10-2022 */
.elementor-heading-title{padding:0;margin:0;line-height:1}.elementor-widget-heading .elementor-heading-title[class*=elementor-size-]>a{color:inherit;font-size:inherit;line-height:inherit}.elementor-widget-heading .elementor-heading-title.elementor-size-small{font-size:15px}.elementor-widget-heading .elementor-heading-title.elementor-size-medium{font-size:19px}.elementor-widget-heading .elementor-heading-title.elementor-size-large{font-size:29px}.elementor-widget-heading .elementor-heading-title.elementor-size-xl{font-size:39px}.elementor-widget-heading .elementor-heading-title.elementor-size-xxl{font-size:59px}</style><h2 class="elementor-heading-title elementor-size-default">Sobre Nós</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-47d8ecf elementor-widget elementor-widget-text-editor" data-id="47d8ecf" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
			<style>/*! elementor - v3.7.8 - 02-10-2022 */
.elementor-widget-text-editor.elementor-drop-cap-view-stacked .elementor-drop-cap{background-color:#818a91;color:#fff}.elementor-widget-text-editor.elementor-drop-cap-view-framed .elementor-drop-cap{color:#818a91;border:3px solid;background-color:transparent}.elementor-widget-text-editor:not(.elementor-drop-cap-view-default) .elementor-drop-cap{margin-top:8px}.elementor-widget-text-editor:not(.elementor-drop-cap-view-default) .elementor-drop-cap-letter{width:1em;height:1em}.elementor-widget-text-editor .elementor-drop-cap{float:left;text-align:center;line-height:1;font-size:50px}.elementor-widget-text-editor .elementor-drop-cap-letter{display:inline-block}</style>				<p><strong>Solidez e segurança a serviço dos brasileiros </strong></p><p><strong>A Crédito popular é uma empresa do grupo 3RN Empréstimos</strong></p><p>O crédito possibilita a realização de sonhos, o investimento em grandes projetos e impulsiona a economia de um país. Por isso, para a Crédito Popular Empréstimos, nada é mais importante que viabilizar o resgate do crédito para muitos brasileiros que nela acreditam ou, ainda, que tenham na Crédito Popular Empréstimos a única possibilidade para a solução dos problemas. A Crédito Popular Empréstimos trabalha em sintonia com a crença de que uma sociedade economicamente saudável transforma um país, além disso, compartilha seus ideais com milhares de colaboradores que, diariamente, atendem aos clientes dentro dos mais rígidos padrões éticos e de respeitabilidade, construídos ao longo destes mais de 17 anos de solidez e eficácia na gestão de uma das empresas mais sólidas do mercado financeiro nacional.</p>						</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-fc55802" data-id="fc55802" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-2edf607 elementor-widget elementor-widget-heading" data-id="2edf607" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Fale Conosco</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-c666c48 elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="c666c48" data-element_type="widget" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
			<link rel="stylesheet" href="https://creditopopularemprestimos.com.br/wp-content/plugins/elementor/assets/css/widget-icon-list.min.css">		<ul class="elementor-icon-list-items">
							<li class="elementor-icon-list-item">
											<a href="https://bit.ly/sitecreditopopular">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="fab fa-whatsapp"></i>						</span>
										<span class="elementor-icon-list-text">(62) 9 9697-0160</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="tel:6233753965">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="fas fa-phone-alt"></i>						</span>
										<span class="elementor-icon-list-text">(62) 3375 3965</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="tel:08004440008">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="fas fa-phone-alt"></i>						</span>
										<span class="elementor-icon-list-text">0800 444 0008</span>
											</a>
									</li>
						</ul>
				</div>
				</div>
				<div class="elementor-element elementor-element-83832cf elementor-shape-circle e-grid-align-left elementor-grid-0 elementor-widget elementor-widget-social-icons" data-id="83832cf" data-element_type="widget" data-widget_type="social-icons.default">
				<div class="elementor-widget-container">
					<div class="elementor-social-icons-wrapper elementor-grid">
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-facebook elementor-repeater-item-1640b17" href="https://www.facebook.com/creditopopularfgtseinss" target="_blank">
						<span class="elementor-screen-only">Facebook</span>
						<i class="fab fa-facebook"></i>					</a>
				</span>
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-instagram elementor-repeater-item-9382c1f" href="https://www.instagram.com/creditopopularemprestimos/" target="_blank">
						<span class="elementor-screen-only">Instagram</span>
						<i class="fab fa-instagram"></i>					</a>
				</span>
					</div>
				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-a123343" data-id="a123343" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-2bb74a6 elementor-widget elementor-widget-heading" data-id="2bb74a6" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Links Úteis</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-c388501 elementor-nav-menu__align-left elementor-nav-menu--dropdown-none elementor-widget elementor-widget-nav-menu" data-id="c388501" data-element_type="widget" data-settings="{&quot;layout&quot;:&quot;vertical&quot;,&quot;submenu_icon&quot;:{&quot;value&quot;:&quot;&lt;i class=\&quot;fas fa-caret-down\&quot;&gt;&lt;\/i&gt;&quot;,&quot;library&quot;:&quot;fa-solid&quot;}}" data-widget_type="nav-menu.default">
				<div class="elementor-widget-container">
						<nav migration_allowed="1" migrated="0" role="navigation" class="elementor-nav-menu--main elementor-nav-menu__container elementor-nav-menu--layout-vertical e--pointer-underline e--animation-fade">
				<ul id="menu-1-c388501" class="elementor-nav-menu sm-vertical"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-582"><a href="https://creditopopularemprestimos.com.br/agencias/" class="elementor-item">Agências</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-177"><a href="http://creditopopularemprestimos.com.br/#vantagens" class="elementor-item elementor-item-anchor">Vantagens</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1075"><a class="elementor-item">Empréstimos</a>
<ul class="sub-menu elementor-nav-menu--dropdown">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1076"><a href="https://creditopopularemprestimos.com.br/representante-legal/" class="elementor-sub-item">Representante Legal</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-1077"><a href="https://creditopopularemprestimos.com.br/" class="elementor-sub-item">Saque Aniversário FGTS</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1082"><a href="https://api.whatsapp.com/send?phone=5562996970160&#038;text=Ol%C3%A1%2C%20%20gostaria%20de%20fazer%20uma%20simula%C3%A7%C3%A3o%20para%20empr%C3%A9stimo%20Consignado%20Federal%2FEstadual" class="elementor-sub-item">Consignado Federal/Estadual</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-178"><a href="http://creditopopularemprestimos.com.br/#duvidas" class="elementor-item elementor-item-anchor">Dúvidas Frequentes</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-587"><a href="https://creditopopularemprestimos.com.br/sobre-nos/" class="elementor-item">Sobre Nós</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-603"><a href="https://creditopopularemprestimos.com.br/fale-conosco/" class="elementor-item">Fale Conosco</a></li>
</ul>			</nav>
					<div class="elementor-menu-toggle" role="button" tabindex="0" aria-label="Menu Toggle" aria-expanded="false">
			<i aria-hidden="true" role="presentation" class="elementor-menu-toggle__icon--open eicon-menu-bar"></i><i aria-hidden="true" role="presentation" class="elementor-menu-toggle__icon--close eicon-close"></i>			<span class="elementor-screen-only">Menu</span>
		</div>
			<nav class="elementor-nav-menu--dropdown elementor-nav-menu__container" role="navigation" aria-hidden="true">
				<ul id="menu-2-c388501" class="elementor-nav-menu sm-vertical"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-582"><a href="https://creditopopularemprestimos.com.br/agencias/" class="elementor-item" tabindex="-1">Agências</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-177"><a href="http://creditopopularemprestimos.com.br/#vantagens" class="elementor-item elementor-item-anchor" tabindex="-1">Vantagens</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1075"><a class="elementor-item" tabindex="-1">Empréstimos</a>
<ul class="sub-menu elementor-nav-menu--dropdown">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1076"><a href="https://creditopopularemprestimos.com.br/representante-legal/" class="elementor-sub-item" tabindex="-1">Representante Legal</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-1077"><a href="https://creditopopularemprestimos.com.br/" class="elementor-sub-item" tabindex="-1">Saque Aniversário FGTS</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1082"><a href="https://api.whatsapp.com/send?phone=5562996970160&#038;text=Ol%C3%A1%2C%20%20gostaria%20de%20fazer%20uma%20simula%C3%A7%C3%A3o%20para%20empr%C3%A9stimo%20Consignado%20Federal%2FEstadual" class="elementor-sub-item" tabindex="-1">Consignado Federal/Estadual</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-178"><a href="http://creditopopularemprestimos.com.br/#duvidas" class="elementor-item elementor-item-anchor" tabindex="-1">Dúvidas Frequentes</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-587"><a href="https://creditopopularemprestimos.com.br/sobre-nos/" class="elementor-item" tabindex="-1">Sobre Nós</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-603"><a href="https://creditopopularemprestimos.com.br/fale-conosco/" class="elementor-item" tabindex="-1">Fale Conosco</a></li>
</ul>			</nav>
				</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-c11ffdf elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="c11ffdf" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-cb743ee" data-id="cb743ee" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-ceedead elementor-widget elementor-widget-text-editor" data-id="ceedead" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p>CP INTERMEDIACOES DE NEGOCIOS LTDA CNPJ: 34.516.301/0001-94</p>						</div>
				</div>
				<div class="elementor-element elementor-element-92b00d1 elementor-align-left elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="92b00d1" data-element_type="widget" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
					<ul class="elementor-icon-list-items">
							<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="fas fa-map-marker-alt"></i>						</span>
										<span class="elementor-icon-list-text">PC BALDUINO DA SILVA CALDAS QUADRA 25 LOTE 16 SALA 2 N° 178 CENTRO, ITABERAÍ - GO 76630-000</span>
									</li>
						</ul>
				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-1d236e9" data-id="1d236e9" data-element_type="column">
			<div class="elementor-widget-wrap">
									</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-bdb4785" data-id="bdb4785" data-element_type="column">
			<div class="elementor-widget-wrap">
									</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-1c3dad5 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="1c3dad5" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-2b9d683" data-id="2b9d683" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-d1fb1fa elementor-widget elementor-widget-text-editor" data-id="d1fb1fa" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p>A CP INTERMEDIACOES DE NEGOCIOS LTDA não é uma instituição financeira e não realiza operações de crédito diretamente. A CP INTERMEDIACOES DE NEGOCIOS LTDA é uma plataforma digital que atua como correspondente bancário para facilitar o processo de contratação de empréstimos. Como correspondente bancário, seguimos as diretrizes do Banco Central do Brasil, nos termos da Resolução nº. 3.954, de 24 de fevereiro de 2011. Toda avaliação de crédito será realizada conforme a política de crédito da Instituição Financeira escolhida pelo usuário. Antes da contratação de qualquer serviço através de nossos parceiros, você receberá todas as condições e informações relativas ao produto a ser contrato, de forma completa e transparente. As taxas de juros, margem consignável e prazo de pagamento praticados nos empréstimos com consignação em pagamento dos Governos Federais, Estaduais e Municipais, Forças armadas e INSS observam as determinações de cada convênio, bem como a política de crédito da instituição financeira a ser utilizada. CP INTERMEDIACOES DE NEGOCIOS LTDA &#8211; CNPJ 34.516.301/0001-94| Endereço: PC BALDUINO DA SILVA CALDAS, 178 &#8211; QUADRA25 LOTE 16 SALA 2 &#8211; CETRO &#8211; 76.630-000 – ITABERAÍ/GO. Bancos parceiros: BANCO SAFRA S.A. 58.160.789/0001-28, BANCO C6 CONSIGNADO 61.348.538/0001-86, FACTA FINANCEIRA 01.360.251/0001-40. Informações adicionais sobre antecipação saque-aniversário: Taxa de juros 2,04% a.m e Custo Efetivo Total máximo de 2,12% a.m. Pagamento debitado anualmente direto na(s) conta(s) vinculadas ao FGTS. É possível realizar a quitação a qualquer momento após a contratação. Valor mínimo R$ 200,00. Exemplo: Considerando a data de operação em Março de 2023 e aniversário no mês de julho, uma conta com saldo de R$ 3.000,00 no FGTS consegue ter R$ 1.676,66 antecipados provenientes do saldo total a serem pagos em 12 parcelas anuais com taxa de juros de 2,04% a.m e CET de 2,12% a.m.</p>						</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-043b379 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="043b379" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-d588cc4" data-id="d588cc4" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-5165250 elementor-widget elementor-widget-text-editor" data-id="5165250" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p>© Copyright Crédito Popular Empréstimos 2023 | All rights reserved</p>						</div>
				</div>
					</div>
		</div>
							</div>
		</section>
						</div>
		
<link rel='stylesheet' id='jeg-dynamic-style-css' href='https://creditopopularemprestimos.com.br/wp-content/plugins/jeg-elementor-kit/lib/jeg-framework/assets/css/jeg-dynamic-styles.css?ver=1.2.9' type='text/css' media='all' />
<script type="text/javascript" src="https://creditopopularemprestimos.com.br/wp-content/themes/hello-elementor/assets/js/hello-frontend.min.js?ver=1.0.0" id="hello-theme-frontend-js"></script>
<script type="text/javascript" src="https://creditopopularemprestimos.com.br/wp-content/plugins/elementor/assets/js/webpack.runtime.min.js?ver=3.7.8" id="elementor-webpack-runtime-js"></script>
<script type="text/javascript" src="https://creditopopularemprestimos.com.br/wp-content/plugins/elementor/assets/js/frontend-modules.min.js?ver=3.7.8" id="elementor-frontend-modules-js"></script>
<script type="text/javascript" src="https://creditopopularemprestimos.com.br/wp-content/plugins/elementor/assets/lib/waypoints/waypoints.min.js?ver=4.0.2" id="elementor-waypoints-js"></script>
<script type="text/javascript" src="https://creditopopularemprestimos.com.br/wp-includes/js/jquery/ui/core.min.js?ver=1.13.2" id="jquery-ui-core-js"></script>
<script type="text/javascript" id="elementor-frontend-js-before">
/* <![CDATA[ */
var elementorFrontendConfig = {"environmentMode":{"edit":false,"wpPreview":false,"isScriptDebug":false},"i18n":{"shareOnFacebook":"Compartilhar no Facebook","shareOnTwitter":"Compartilhar no Twitter","pinIt":"Fixar","download":"Baixar","downloadImage":"Baixar imagem","fullscreen":"Tela cheia","zoom":"Zoom","share":"Compartilhar","playVideo":"Reproduzir v\u00eddeo","previous":"Anterior","next":"Pr\u00f3ximo","close":"Fechar"},"is_rtl":false,"breakpoints":{"xs":0,"sm":480,"md":768,"lg":1025,"xl":1440,"xxl":1600},"responsive":{"breakpoints":{"mobile":{"label":"Celular","value":767,"default_value":767,"direction":"max","is_enabled":true},"mobile_extra":{"label":"Celular extra","value":880,"default_value":880,"direction":"max","is_enabled":false},"tablet":{"label":"Tablet","value":1024,"default_value":1024,"direction":"max","is_enabled":true},"tablet_extra":{"label":"Tablet extra","value":1200,"default_value":1200,"direction":"max","is_enabled":false},"laptop":{"label":"Laptop","value":1366,"default_value":1366,"direction":"max","is_enabled":false},"widescreen":{"label":"Widescreen","value":2400,"default_value":2400,"direction":"min","is_enabled":false}}},"version":"3.7.8","is_static":false,"experimentalFeatures":{"e_dom_optimization":true,"e_optimized_assets_loading":true,"e_optimized_css_loading":true,"a11y_improvements":true,"e_import_export":true,"e_hidden_wordpress_widgets":true,"theme_builder_v2":true,"hello-theme-header-footer":true,"landing-pages":true,"elements-color-picker":true,"favorite-widgets":true,"admin-top-bar":true,"page-transitions":true,"notes":true,"form-submissions":true,"e_scroll_snap":true},"urls":{"assets":"https:\/\/creditopopularemprestimos.com.br\/wp-content\/plugins\/elementor\/assets\/"},"settings":{"editorPreferences":[]},"kit":{"active_breakpoints":["viewport_mobile","viewport_tablet"],"global_image_lightbox":"yes","lightbox_enable_counter":"yes","lightbox_enable_fullscreen":"yes","lightbox_enable_zoom":"yes","lightbox_enable_share":"yes","lightbox_title_src":"title","lightbox_description_src":"description","hello_header_logo_type":"logo","hello_header_menu_layout":"horizontal","hello_footer_logo_type":"logo"},"post":{"id":0,"title":"P\u00e1gina n\u00e3o encontrada &#8211; Cr\u00e9dito Popular Empr\u00e9stimos","excerpt":""}};
/* ]]> */
</script>
<script type="text/javascript" src="https://creditopopularemprestimos.com.br/wp-content/plugins/elementor/assets/js/frontend.min.js?ver=3.7.8" id="elementor-frontend-js"></script>
<script type="text/javascript" id="elementor-frontend-js-after">
/* <![CDATA[ */
var jkit_ajax_url = "https://creditopopularemprestimos.com.br/?jkit-ajax-request=jkit_elements", jkit_nonce = "d04f24e083";
/* ]]> */
</script>
<script type="text/javascript" src="https://creditopopularemprestimos.com.br/wp-content/plugins/jeg-elementor-kit/assets/js/elements/sticky-element.js?ver=2.6.1" id="jkit-sticky-element-js"></script>
<script type="text/javascript" id="eael-general-js-extra">
/* <![CDATA[ */
var localize = {"ajaxurl":"https:\/\/creditopopularemprestimos.com.br\/wp-admin\/admin-ajax.php","nonce":"a58517fe41","i18n":{"added":"Added ","compare":"Compare","loading":"Loading..."},"page_permalink":"","cart_redirectition":"","cart_page_url":"","el_breakpoints":{"mobile":{"label":"Celular","value":767,"default_value":767,"direction":"max","is_enabled":true},"mobile_extra":{"label":"Celular extra","value":880,"default_value":880,"direction":"max","is_enabled":false},"tablet":{"label":"Tablet","value":1024,"default_value":1024,"direction":"max","is_enabled":true},"tablet_extra":{"label":"Tablet extra","value":1200,"default_value":1200,"direction":"max","is_enabled":false},"laptop":{"label":"Laptop","value":1366,"default_value":1366,"direction":"max","is_enabled":false},"widescreen":{"label":"Widescreen","value":2400,"default_value":2400,"direction":"min","is_enabled":false}}};
/* ]]> */
</script>
<script type="text/javascript" src="https://creditopopularemprestimos.com.br/wp-content/plugins/essential-addons-for-elementor-lite/assets/front-end/js/view/general.min.js?ver=5.4.6" id="eael-general-js"></script>
<script type="text/javascript" src="https://creditopopularemprestimos.com.br/wp-content/plugins/elementor-pro/assets/lib/smartmenus/jquery.smartmenus.min.js?ver=1.0.1" id="smartmenus-js"></script>
<script type="text/javascript" src="https://creditopopularemprestimos.com.br/wp-content/plugins/elementor-pro/assets/js/webpack-pro.runtime.min.js?ver=3.7.7" id="elementor-pro-webpack-runtime-js"></script>
<script type="text/javascript" src="https://creditopopularemprestimos.com.br/wp-includes/js/dist/vendor/wp-polyfill-inert.min.js?ver=3.1.2" id="wp-polyfill-inert-js"></script>
<script type="text/javascript" src="https://creditopopularemprestimos.com.br/wp-includes/js/dist/vendor/regenerator-runtime.min.js?ver=0.14.0" id="regenerator-runtime-js"></script>
<script type="text/javascript" src="https://creditopopularemprestimos.com.br/wp-includes/js/dist/vendor/wp-polyfill.min.js?ver=3.15.0" id="wp-polyfill-js"></script>
<script type="text/javascript" src="https://creditopopularemprestimos.com.br/wp-includes/js/dist/hooks.min.js?ver=2810c76e705dd1a53b18" id="wp-hooks-js"></script>
<script type="text/javascript" src="https://creditopopularemprestimos.com.br/wp-includes/js/dist/i18n.min.js?ver=5e580eb46a90c2b997e6" id="wp-i18n-js"></script>
<script type="text/javascript" id="wp-i18n-js-after">
/* <![CDATA[ */
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );
/* ]]> */
</script>
<script type="text/javascript" id="elementor-pro-frontend-js-before">
/* <![CDATA[ */
var ElementorProFrontendConfig = {"ajaxurl":"https:\/\/creditopopularemprestimos.com.br\/wp-admin\/admin-ajax.php","nonce":"3dd1a61724","urls":{"assets":"https:\/\/creditopopularemprestimos.com.br\/wp-content\/plugins\/elementor-pro\/assets\/","rest":"https:\/\/creditopopularemprestimos.com.br\/wp-json\/"},"shareButtonsNetworks":{"facebook":{"title":"Facebook","has_counter":true},"twitter":{"title":"Twitter"},"linkedin":{"title":"LinkedIn","has_counter":true},"pinterest":{"title":"Pinterest","has_counter":true},"reddit":{"title":"Reddit","has_counter":true},"vk":{"title":"VK","has_counter":true},"odnoklassniki":{"title":"OK","has_counter":true},"tumblr":{"title":"Tumblr"},"digg":{"title":"Digg"},"skype":{"title":"Skype"},"stumbleupon":{"title":"StumbleUpon","has_counter":true},"mix":{"title":"Mix"},"telegram":{"title":"Telegram"},"pocket":{"title":"Pocket","has_counter":true},"xing":{"title":"XING","has_counter":true},"whatsapp":{"title":"WhatsApp"},"email":{"title":"Email"},"print":{"title":"Print"}},"facebook_sdk":{"lang":"pt_BR","app_id":""},"lottie":{"defaultAnimationUrl":"https:\/\/creditopopularemprestimos.com.br\/wp-content\/plugins\/elementor-pro\/modules\/lottie\/assets\/animations\/default.json"}};
/* ]]> */
</script>
<script type="text/javascript" src="https://creditopopularemprestimos.com.br/wp-content/plugins/elementor-pro/assets/js/frontend.min.js?ver=3.7.7" id="elementor-pro-frontend-js"></script>
<script type="text/javascript" src="https://creditopopularemprestimos.com.br/wp-content/plugins/elementor-pro/assets/js/elements-handlers.min.js?ver=3.7.7" id="pro-elements-handlers-js"></script>

</body>
</html>
